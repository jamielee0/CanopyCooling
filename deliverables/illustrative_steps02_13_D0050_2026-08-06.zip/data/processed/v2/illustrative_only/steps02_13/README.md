# Illustrative-only Guide Steps 2–13

**Status:** `STOP_USER_SKIPPED_D0047_GEOMETRY_710_OF_911`

This directory is a quarantined, offline demonstration produced after the user
directed the D0047 geometry run to stop at 710 of 911 candidates. It is not a
canonical Task-1 result, is not scientifically gate-eligible, and does not
activate Task 2.

## Real nonthermal facts retained

- 2,968 catalogue metadata rows.
- 1,055 daytime catalogue-ceiling passes; this is not a usable-pass count.
- 911 D0047 archive-available geometry candidates.
- 710 candidates evaluated at the stop snapshot.
- 201 candidates unevaluated.

## Interpretation boundary

`empirical_nonthermal/` contains only real catalogue metadata and the incomplete
geometry checkpoint facts. `synthetic_downstream/` contains illustrative outputs
that demonstrate file shapes and analytical workflows. Every figure is visibly
labelled as illustrative/synthetic and every filename is prefixed accordingly.

No ECOSTRESS LST or thermal value was opened. The holdout remains `UNSELECTED`,
the 2026 record remains unopened, and the canonical Task-1 gate remains `STOP`.

Figures are stored separately at `/Users/jmlee/Documents/TreeProject/project/figures/v2/illustrative_only/steps02_13`. `data_origin_dictionary.csv`
maps every required deliverable ID to its origin. `run_manifest.json` contains
SHA-256 hashes for the package artifacts.
