# ILLUSTRATIVE Step 14 — Limitations and claim boundaries

> ILLUSTRATIVE — SYNTHETIC DATA — NOT A STUDY RESULT

data_origin: synthetic_and_nonthermal_metadata  
canonical_eligible: false  
illustrative_seed: 20260805  
workflow_status: STOP_USER_SKIPPED_D0047_GEOMETRY_710_OF_911  
scientific_gate_eligible: false  
task1_gate: STOP  
task2_activated: false  
lst_opened: false  
thermal_opened: false  
holdout_status: UNSELECTED  
record_2026_opened: false

1. The current package contains synthetic downstream demonstrations and a partial nonthermal catalogue snapshot. It contains no eligible empirical cooling result.
2. Time-of-day dependence would compare observations from different dates; it must not be described as a same-day diurnal trajectory.
3. Clear-sky satellite sampling can differ systematically from all summer weather and limits generalization; the required empirical quantification is not available in this package.
4. Antecedent climatic dryness or water balance is a climatic exposure, not soil water, root-zone water, irrigation, or plant-available water.
5. Surface temperature is not leaf temperature, pedestrian comfort, mean radiant temperature, or a demonstrated reduction in near-surface air temperature.
6. Radiative adjustment is incomplete for shadow history, crown geometry, sky-view factor, roughness, thermal inertia, directional anisotropy, and other unresolved controls.
7. Five purposively selected cities are cases, not a probability sample of United States cities; no national population claim is supported.
8. D0047 geometry is incomplete, the real usable-pass total is unavailable, and cloud survival is incomplete; the Task-1 gate therefore remains STOP.
9. The held-out city and 2026 record remain sealed; there is no confirmatory result to interpret.
10. The scene/version inventory is a synthetic metadata crosswalk. Its download dates are explicitly not applicable and it is not a real source-data ledger.
11. P14.1 is a checksum inventory for the quarantined files, not a public scientific release; this document layer does not itself supply public code, a canonical decision log, or an independent rebuild.
