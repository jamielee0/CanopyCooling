# ILLUSTRATIVE M14.1 — Go / adjust / stop memo

> ILLUSTRATIVE — SYNTHETIC DATA — NOT A STUDY RESULT

data_origin: synthetic_and_nonthermal_metadata  
canonical_eligible: false  
illustrative_seed: 20260805  
workflow_status: STOP_USER_SKIPPED_D0047_GEOMETRY_710_OF_911  
scientific_gate_eligible: false  
task1_gate: STOP  
task2_activated: false  
lst_opened: false  
thermal_opened: false  
holdout_status: UNSELECTED  
record_2026_opened: false

## Decision

**STOP for empirical, manuscript, and confirmatory claims.** The only permitted
continuation is the explicitly quarantined illustrative package. This memo does
not authorize Task 2, thermal/LST access, holdout selection, 2026 access, or a
scientific conclusion.

## Basis

- Task-1 gate remains **STOP** and scientific-gate eligibility remains false.
- D0047 geometry was evaluated for 710 of 911 candidates; 201 remained unevaluated.
- Cloud survival and the real usable-pass count are not complete.
- LST and thermal inputs remain unopened; therefore no empirical endpoint was estimated.
- The held-out city is **UNSELECTED**, and the 2026 record remains unopened.
- Steps 3–14 demonstrations use synthetic or nonthermal metadata and are not study results.

## Guide decision criteria

| Criterion | Current evidence | Disposition |
|---|---|---|
| Primary endpoint is stable | No empirical thermal endpoint exists | Not evaluated |
| Radiative standardization survives scrutiny | Synthetic demonstration only | Not evaluated |
| Placebo and night checks behave | Synthetic demonstration only | Not evaluated |
| Effect exceeds the combined detection limit | No empirical effect estimate exists | Not evaluated |

Because none of the scientific decision criteria has been evaluated on eligible
data, manuscript drafting and confirmatory opening remain out of scope. A later
run must complete the real Task-1 prerequisites and freeze its method before any
held-out thermal or 2026 record is opened. If a future eligible interaction
analysis fails, the guide's adjustment is to retain only a supportable
time-of-day paper and state the sampling limitation.
