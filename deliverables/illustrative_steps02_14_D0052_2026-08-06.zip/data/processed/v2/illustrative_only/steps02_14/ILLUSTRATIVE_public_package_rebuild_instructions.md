# Illustrative package rebuild instructions

**Status:** `STOP_USER_SKIPPED_D0047_GEOMETRY_710_OF_911`  
**Scientific gate eligible:** `false`  
**Data origin:** source code, governance records, empirical nonthermal partial
metadata, and deterministic synthetic demonstrations

From the repository root, activate the environment described by
`environment.yml`, then run:

```text
PYTHONPATH=src python src/run_v2_illustrative_steps02_14.py
```

The runner blocks network access during every illustrative writer, refuses
repository outputs outside `illustrative_only`, requires all 102 registry IDs
exactly once, verifies origin and false-eligibility columns on every CSV, and
hashes every non-manifest output. The authoritative verification ledger is
`data/processed/v2/illustrative_only/steps02_14/run_manifest.json`.

This rebuild reproduces an illustrative workflow package only. It does not open
or reproduce a canonical thermal result, select the holdout, open the real 2026
record, activate Task 2, or satisfy the guide's canonical Step-14 gate.
