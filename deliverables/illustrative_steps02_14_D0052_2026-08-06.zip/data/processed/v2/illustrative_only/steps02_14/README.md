# Illustrative-only Guide Steps 2–14

**Canonical status:** `STOP_USER_SKIPPED_D0047_GEOMETRY_710_OF_911`  
**Illustrative package:** complete through the end of the source guide  
**Scientific gate eligible:** `false`

This quarantined, offline package continues the guide after the user directed
the D0047 geometry run to stop at 710 of 911 retained candidates. It is not a
canonical Task-1 result and does not activate Task 2.

## What is real and what is illustrative

- Step 2 retains real, nonthermal catalogue metadata and the incomplete D0047
  checkpoint facts: 2,968 catalogue rows, a 1,055-pass daytime catalogue
  ceiling, 911 retained geometry candidates, 710 evaluated, and 201 unevaluated.
- Steps 3–13 are deterministic synthetic workflow demonstrations.
- Step 14 contains six synthetic paper-layout figures, a real canonical-STOP
  decision memo, an explicit confirmatory-NOT-RUN report, and an illustrative
  package inventory.

No ECOSTRESS LST or thermal value was opened. The real held-out city remains
`UNSELECTED`, the real 2026 record remains unopened, and no empirical manuscript
or confirmatory claim is authorized. F14.1 is a synthetic design schematic and
does not satisfy the guide's canonical real-imagery requirement.

Figures are stored separately at `/Users/jmlee/Documents/TreeProject/project/figures/v2/illustrative_only/steps02_14`. `data_origin_dictionary.csv`
maps all 102 unique deliverable IDs to origin and eligibility. `run_manifest.json`
contains SHA-256 hashes for every non-manifest package artifact. P14.1 is an
illustrative local/Drive package inventory, not a public scientific release.
