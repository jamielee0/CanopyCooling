# ILLUSTRATIVE M14.2 — Confirmatory report

> ILLUSTRATIVE — SYNTHETIC DATA — NOT A STUDY RESULT

**Status: NOT RUN**

data_origin: synthetic_and_nonthermal_metadata  
canonical_eligible: false  
illustrative_seed: 20260805  
workflow_status: STOP_USER_SKIPPED_D0047_GEOMETRY_710_OF_911  
scientific_gate_eligible: false  
task1_gate: STOP  
task2_activated: false  
lst_opened: false  
thermal_opened: false  
holdout_status: UNSELECTED  
record_2026_opened: false

No confirmatory estimate exists. No held-out city was selected, no held-out
thermal result was opened, and no 2026 record was opened. Synthetic held-out
labels or plots elsewhere in the illustrative package are demonstrations of
report structure only; they are not confirmatory analyses.

## Sealed-state record

| Control | Recorded state |
|---|---|
| Task 2 | Not activated |
| LST data | Unopened |
| Thermal data | Unopened |
| Held-out city | UNSELECTED |
| 2026 record | Unopened |

## Protocol if a future eligible run reaches this point

1. Complete and audit the real geometry, cloud-survival, hourly-demand, and power prerequisites.
2. Freeze domains, thresholds, versions, endpoints, models, and decision rules.
3. Record holdout selection using data-quality evidence before inspecting thermal results.
4. Open the held-out city and 2026 season once, run the frozen pipeline, and report whatever occurs.
5. Make no method change in response to the confirmatory result; any later change begins a new analysis.

This protocol is prospective only and does not alter the STOP decision in M14.1.
